document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".product__counter-minus").forEach(btn => {
        btn.addEventListener("click", function () {
            let input = this.nextElementSibling;
            let value = parseInt(input.value);
            if (value > 1) input.value = value - 1;
        });
    });

    document.querySelectorAll(".product__counter-plus").forEach(btn => {
        btn.addEventListener("click", function () {
            let input = this.previousElementSibling;
            let value = parseInt(input.value);
            input.value = value + 1;
        });
    });

    document.querySelectorAll(".product__counter-coll").forEach(input => {
        input.addEventListener("input", function () {
            if (this.value < 1) this.value = 1;
        });
    });
});
